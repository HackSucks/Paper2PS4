
varying mediump vec4 v_Color;

void main() {
	gl_FragColor = v_Color;
}
