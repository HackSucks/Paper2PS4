
#include "base/model_vertex_v1.h"

uniform vec3 g_EyePosition;
uniform mat4 g_ViewProjectionMatrix;

attribute vec3 a_Position;
attribute vec3 a_Normal;
attribute vec2 a_TexCoord;
#if HLSL
in uint gl_InstanceID;
#endif

varying vec4 v_WorldNormal;
varying vec4 v_ViewDir;

varying vec2 v_TexCoord;
varying vec3 v_LightAmbientColor;

#if LIGHTING || REFLECTION
#if NORMALMAP
varying vec3 v_Tangent;
varying vec3 v_Bitangent;
#else
#endif
varying vec3 v_WorldPos;
#endif

#if REFLECTION
varying vec3 v_ScreenPos;
#endif

#if MORPHING
uniform sampler2D g_Texture5; // {"material":"morph","hidden":true}
uniform vec4 g_Texture5Texel;
#endif

uniform sampler2D g_Texture0; // {"material":"albedo","label":"ui_editor_properties_albedo","default":"util/white"}

// <Fur additions
uniform float g_FurDistance; // {"material":"furdistance","label":"ui_editor_properties_distance","default":0.1,"range":[0.001, 20],"group":"ui_editor_properties_fur"}
// Fur additions>

void main() {
	vec3 localPos = a_Position;
	vec3 localNormal = a_Normal;

#if MORPHING
	ApplyMorphPositionNormal(CASTU(gl_VertexID), MAKE_SAMPLER2D_ARGUMENT(g_Texture5), g_Texture5Texel, g_MorphOffsets, g_MorphWeights, localPos, localNormal);
#endif

	vec4 worldPos;
	vec3 worldNormal;
#if SKINNING
	ApplySkinningPositionNormal(localPos, localNormal, a_BlendIndices, a_BlendWeights, worldPos, worldNormal);
#else
	ApplyPositionNormal(localPos, localNormal, worldPos, worldNormal);
#endif

	// <Fur additions
	float furDistance = texSample2DLod(g_Texture0, a_TexCoord.xy, 0.0).a;
	v_WorldNormal.w = CASTF(gl_InstanceID) / (CASTF(INSTANCECOUNT) - 1.0);
	worldPos.xyz += worldNormal * v_WorldNormal.w * g_FurDistance * furDistance;
	// Fur additions>

	gl_Position = mul(worldPos, g_ViewProjectionMatrix);

	v_TexCoord.xy = a_TexCoord;
	v_ViewDir.xyz = g_EyePosition - worldPos.xyz;
	v_ViewDir.w = worldPos.y;

#if LIGHTING || REFLECTION
	v_WorldPos = worldPos.xyz;

#if NORMALMAP
#if SKINNING
	ApplySkinningTangentSpace(localNormal, a_Tangent4, a_BlendIndices, a_BlendWeights, v_Tangent, v_Bitangent);
#else
	ApplyTangentSpace(localNormal, a_Tangent4, v_Tangent, v_Bitangent);
#endif
#endif

#endif

	v_WorldNormal.xyz = worldNormal;

#if REFLECTION
	ClipSpaceToScreenSpace(gl_Position, v_ScreenPos);
#endif

	v_LightAmbientColor = ApplyAmbientLighting(worldNormal);
}
