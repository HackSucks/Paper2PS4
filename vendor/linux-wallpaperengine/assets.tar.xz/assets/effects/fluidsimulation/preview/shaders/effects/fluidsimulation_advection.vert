
// [COMBO] {"material":"ui_editor_properties_perspective","combo":"PERSPECTIVE","type":"options","default":0}

#include "common_perspective.h"

attribute vec3 a_Position;
attribute vec2 a_TexCoord;

varying vec2 v_TexCoord;

#if PERSPECTIVE == 1
uniform vec2 g_Point0; // {"hidden":true,"material":"point0","label":"p0","default":"0 0"}
uniform vec2 g_Point1; // {"hidden":true,"material":"point1","label":"p1","default":"1 0"}
uniform vec2 g_Point2; // {"hidden":true,"material":"point2","label":"p2","default":"1 1"}
uniform vec2 g_Point3; // {"hidden":true,"material":"point3","label":"p3","default":"0 1"}
varying vec3 v_TexCoordPerspective;
#endif

void main() {
	gl_Position = vec4(a_Position, 1.0);
	v_TexCoord = a_TexCoord.xy;
	
#if PERSPECTIVE == 1
	mat3 xform = squareToQuad(g_Point0, g_Point1, g_Point2, g_Point3);
	v_TexCoordPerspective = mul(vec3(a_TexCoord.xy, 1.0), xform);
#endif
}
